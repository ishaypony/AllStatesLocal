<footer class="page_footer ds ms bg_image section_padding_50">
				<div class="container">
					<div class="row">

						<div class="col-md-3 col-sm-6 to_animate">
							<div class="widget_text">
								<h3 class="widget-title">Why Us?</h3>
								<p>It is our sole aim at Allstates heating and cooling to ensure happiness and satisfaction to our customers.
								Our team provides a quick and responsive service every time you decide to work with Allstate heating and cooling services.
								</p>
								<p class="topmargin_40">
						
					</p>
							</div>
						</div>

						<div class="col-md-3 col-sm-6 to_animate">
							<div class="widget widget_recent_entries">
								<h3 class="widget-title">Our Services</h3>
								<ul>
									<li>
										<p class="post-date">
								<a href="ac_repair.php">AC REPAIR</a>
							</p>
									
									</li>
									<li>
										<p class="post-date">
								<a href="ac_intallation.php">AC INSTALLATION </a>
							</p>
									
									</li>
									<li>
										<p class="post-date">
								<a href="hvac_contractor.php">HVAC CONTRACTOR</a>
							</p>
										
									</li>
								</ul>
							</div>
						</div>

						<div class="col-md-3 col-sm-6 to_animate">
							<div class="widget_text">
								<h3 class="widget-title">Contact Us</h3>
								<p>PO Box 54321 Some str. 765, Los Angeles, California, United States</p>
								<ul class="list1 no-bullets">
									<li>
										<i class="rt-icon2-device-phone highlight"></i> 111-111-1111
									</li>
									<li>
										<i class="rt-icon2-globe-outline highlight"></i> <a href="./">www.company.com</a>
									</li>
									<li>
										<i class="rt-icon2-mail2 highlight"></i> <a href="mailto:info@company.com">info@company.com</a>
									</li>

								</ul>

							</div>
						</div>

						<div class="col-md-3 col-sm-6 to_animate">
							<div class="widget_text">
								<h3 class="widget-title">Stay Connected</h3>
								<div class="media small-teaser">
									<div class="media-left media-middle">
										<a href="#" class="social-icon color-icon border-icon rounded-icon soc-facebook"></a>
									</div>
									<div class="media-body media-middle">
										Facebook
									</div>
								</div>
								<div class="media small-teaser">
									<div class="media-left media-middle">
										<a href="#" class="social-icon color-icon border-icon rounded-icon soc-twitter"></a>
									</div>
									<div class="media-body media-middle">
										Twitter
									</div>
								</div>
								<div class="media small-teaser">
									<div class="media-left media-middle">
										<a href="#" class="social-icon color-icon border-icon rounded-icon soc-linkedin"></a>
									</div>
									<div class="media-body media-middle">
										LinkedIn
									</div>
								</div>
								<div class="media small-teaser">
									<div class="media-left media-middle">
										<a href="#" class="social-icon color-icon border-icon rounded-icon soc-pinterest"></a>
									</div>
									<div class="media-body media-middle">
										Pinterest
									</div>
								</div>

							</div>

						</div>
					</div>
				</div>
			</footer>

			<section class="ls page_copyright section_padding_15">
				<div class="container">
					<div class="row">
						<div class="col-sm-12 text-center">
							<p class="small-text regular grey">&copy; Copyright 2017 All Rights Reserved</p>
						</div>
					</div>
				</div>
				<div class="hidehen"><a href="contact.php" class="theme_button color1 henapt">make appointment</a></div>
			</section>

			</body>

			<script src="js/compressed.js"></script>
	<script src="js/main.js"></script>


	<!-- Google Map Script -->
	<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDTwYSMRGuTsmfl2z_zZDStYqMlKtrybxo"></script>